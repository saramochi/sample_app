# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '99b7473df2debe11795e74c9d1753f2d76a672526b9c22c804f24199e350a6c198950f611743571e09c39fcdb488e02855237af26ac1c7ba62ea299a01b46e77'